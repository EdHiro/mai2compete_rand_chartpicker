import { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { Music } from 'lucide-react'
import { Song, Difficulty, useSongStore } from '@/store/songStore'
import SongCardContent from '@/components/SongCardContent'
import { subscribeSyncEvents, type SyncEvent, getConnectionStatus } from '@/utils/tabSync'

interface DrawCardProps {
  song: Song
  index: number
  showFront: boolean
  animationState: 'enter' | 'exit'
}

const getDifficultyCode = (difficulty: Difficulty): string => {
  switch (difficulty) {
    case 'EXPERT':
      return 'EXP'
    case 'MASTER':
      return 'MST'
    case 'Re:MASTER':
      return 'MST_Re'
  }
}

const getCardBgImage = (difficulty: Difficulty): string => {
  const code = getDifficultyCode(difficulty)
  return `/levbg/Sprite/UI_TST_MBase_${code}.png`
}

const ENTRANCE_BG = '/levbg/Sprite/UI_TST_MBase_DMY.png'

const DrawCard = function ({ song, index, showFront, animationState }: DrawCardProps) {
  const isExiting = animationState === 'exit'
  const bgForBack = isExiting ? getCardBgImage(song.difficulty) : ENTRANCE_BG

  return (
    <div
      className={`relative w-[300px] h-[520px] perspective-1000 ${
        isExiting ? 'animate-cardExit' : 'animate-cardEntrance'
      }`}
      style={{ animationDelay: `${index * 150}ms` }}
    >
      <div
        className={
          `w-full h-full preserve-3d transition-transform duration-1000 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${showFront ? 'rotate-y-180' : ''}`
        }
      >
        <div className="absolute inset-0 backface-hidden">
          <div className="relative w-full h-full rounded-[32px] overflow-hidden shadow-[0_30px_90px_rgba(0,0,0,0.28)] bg-gradient-to-b from-blue-800 to-blue-900">
            <div className="absolute inset-0 animate-cardGlow opacity-40" />
            <img
              src={bgForBack}
              alt="Card Background"
              className="absolute inset-0 w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-black/30" />

            <div className="absolute top-[72px] left-1/2 z-20 w-[220px] -translate-x-1/2">
              <div className="relative h-12 rounded-full bg-white/10 border-2 border-white/30">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-black uppercase tracking-[0.26em] text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.75)]">
                    {song.chartType}
                  </span>
                </div>
              </div>
            </div>

            <div className="absolute top-[150px] left-1/2 z-10 -translate-x-1/2">
              <div className="w-48 h-48 rounded-full bg-white/10 flex items-center justify-center animate-cardPulse">
                <Music size={80} className="text-white/70" />
              </div>
            </div>
          </div>
        </div>

        <div className="absolute inset-0 backface-hidden rotate-y-180">
          <SongCardContent song={song} className="w-full h-full" />
        </div>
      </div>

      <div
        className={`absolute inset-0 pointer-events-none rounded-[32px] z-30 ${
          showFront ? 'animate-cardReveal' : ''
        }`}
      />
    </div>
  )
}

export default function OBSDisplay() {
  const [revealedCount, setRevealedCount] = useState(0)
  const [phase, setPhase] = useState<'idle' | 'building' | 'revealing' | 'done' | 'exiting'>('idle')
  const [displaySongs, setDisplaySongs] = useState<Song[]>([])
  const [exitingSongs, setExitingSongs] = useState<Song[]>([])
  const [exitKey, setExitKey] = useState(0)
  const timeoutRefs = useRef<ReturnType<typeof setTimeout>[]>([])

  // Refs to avoid stale closures in event handlers
  const displaySongsRef = useRef<Song[]>([])
  const phaseRef = useRef(phase)

  useEffect(() => {
    phaseRef.current = phase
  }, [phase])

  useEffect(() => {
    displaySongsRef.current = displaySongs
  }, [displaySongs])

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      timeoutRefs.current.forEach(clearTimeout)
    }
  }, [])

  // Listen for sync events from main tab
  useEffect(() => {
    const handleDrawEvent = (songs: Song[]) => {
      // Use ref to get latest state
      const currentSongs = displaySongsRef.current
      const currentPhase = phaseRef.current

      // If already exiting, ignore the new event
      if (currentPhase === 'exiting') return

      // If there are existing songs, play exit animation first
      if (currentSongs.length > 0) {
        setExitingSongs(currentSongs)
        setPhase('exiting')
        setRevealedCount(0)

        const lastCardDelay = currentSongs.length * 150
        const exitDuration = 600 + lastCardDelay

        timeoutRefs.current.push(
          setTimeout(() => {
            setExitingSongs([])
            // Now play entrance with new songs
            setDisplaySongs(songs)
            setExitKey(prev => prev + 1)
            setRevealedCount(0)
            setPhase('building')

            timeoutRefs.current.push(
              setTimeout(() => {
                setPhase('revealing')
              }, 300)
            )

            songs.forEach((_, index) => {
              const delay = 600 + index * 350
              timeoutRefs.current.push(
                setTimeout(() => {
                  setRevealedCount(index + 1)
                  if (index === songs.length - 1) {
                    setTimeout(() => setPhase('done'), 400)
                  }
                }, delay)
              )
            })
          }, exitDuration)
        )
      } else {
        // First draw, just animate in
        setDisplaySongs(songs)
        setExitKey(prev => prev + 1)
        setRevealedCount(0)
        setPhase('building')

        timeoutRefs.current.push(
          setTimeout(() => {
            setPhase('revealing')
          }, 300)
        )

        songs.forEach((_, index) => {
          const delay = 600 + index * 350
          timeoutRefs.current.push(
            setTimeout(() => {
              setRevealedCount(index + 1)
              if (index === songs.length - 1) {
                setTimeout(() => setPhase('done'), 400)
              }
            }, delay)
          )
        })
      }
    }

    const handleClearEvent = () => {
      const currentSongs = displaySongsRef.current
      if (currentSongs.length > 0) {
        setExitingSongs(currentSongs)
        setPhase('exiting')
        setRevealedCount(0)

        const lastCardDelay = currentSongs.length * 150
        const exitDuration = 600 + lastCardDelay

        timeoutRefs.current.push(
          setTimeout(() => {
            setExitingSongs([])
            setDisplaySongs([])
            setPhase('idle')
          }, exitDuration)
        )
      }
    }

    const handleImportEvent = () => {
      // Reset state when songs are imported
      setDisplaySongs([])
      setExitingSongs([])
      setPhase('idle')
      setRevealedCount(0)
    }

    const unsubscribe = subscribeSyncEvents((event: SyncEvent) => {
      if (event.type === 'draw') {
        const payload = event.payload as { songs: Song[] }
        handleDrawEvent(payload.songs)
      } else if (event.type === 'clear') {
        handleClearEvent()
      } else if (event.type === 'import') {
        handleImportEvent()
      }
    })

    return unsubscribe
  }, [])

  const songsToShow = exitingSongs.length > 0 ? exitingSongs : displaySongs
  const isExitingPhase = exitingSongs.length > 0

  const renderCards = useMemo(
    () => songsToShow.map((song, index) => (
      <div key={`obs-${exitKey}-${index}`}>
        <DrawCard
          song={song}
          index={index}
          showFront={isExitingPhase || index < revealedCount}
          animationState={isExitingPhase ? 'exit' : 'enter'}
        />
      </div>
    )),
    [songsToShow, exitKey, isExitingPhase, revealedCount]
  )

  return (
    <div className="min-h-screen bg-gray-950 py-12 px-4 relative overflow-hidden">
      {/* Background ambient effect */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-radial from-blue-900/10 via-transparent to-transparent" />
      </div>

      {/* Connection status */}
      <div className="relative z-10 text-center mb-6">
        <div className="inline-flex items-center gap-4 px-4 py-3.5 rounded-full text-xs font-bold tracking-wider bg-white/5 border border-white/10">
          {(() => {
            const status = getConnectionStatus()
            if (status === 'connected') {
              return <span className="text-green-400">● 多设备已连接 - 主页面控制</span>
            } else if (status === 'local-only') {
              return <span className="text-yellow-400">● 仅同浏览器联动 (启动 sync-server 以支持多设备)</span>
            }
            return <span className="text-yellow-400">○ 连接中...</span>
          })()}
        </div>
      </div>
  
      {/* Cards area */}
      <div className="relative z-10">
        {(phase === 'revealing' || phase === 'done') && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
            <div className="w-[120%] h-[120%] bg-gradient-radial from-yellow-400/5 via-transparent to-transparent animate-burstFade" />
          </div>
        )}

        <div className="relative z-10 flex flex-wrap justify-center gap-8">
          {renderCards}
        </div>
      </div>
    </div>
  )
}
