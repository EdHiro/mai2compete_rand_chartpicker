import { create } from 'zustand'
import { broadcastSyncEvent } from '@/utils/tabSync'

export type Difficulty = 'EXPERT' | 'MASTER' | 'Re:MASTER'
export type ChartType = 'dx' | 'standard'

export interface Song {
  id: string
  name: string
  difficulty: Difficulty
  level: number
  isPlus: boolean
  cover: string
  author: string
  difficultyAuthor: string
  bpm: number
  chartType: ChartType
}

export interface SongPool {
  id: string
  name: string
  songs: Song[]
}

// 解析输入值字符串（如 "12+"），返回数值（12.5）
function parseInputValue(val: string): number {
  const hasPlus = val.includes('+')
  const numPart = parseInt(val.replace('+', '')) || 1
  return hasPlus ? numPart + 0.5 : numPart
}

/**
 * 解析等级数值，返回可比较的数值
 */
function parseSongLevel(song: Song): number {
  return song.isPlus ? song.level + 0.5 : song.level
}

/**
 * 真随机数生成器 - 使用 Web Crypto API
 * @param max 最大值 (exclusive)，返回 [0, max) 范围的随机整数
 */
function getRandomIndex(max: number): number {
  if (max <= 1) return 0
  const array = new Uint32Array(1)
  crypto.getRandomValues(array)
  return array[0] % max
}

interface SongStore {
  // 单个曲库模式（兼容旧版）
  songs: Song[]
  // 多曲库模式
  songPools: SongPool[]
  // 当前查看的曲库：'main' = 主库, 或 pool.id
  activePoolId: string
  // 当前使用的模式：'single' = 单库, 'multi' = 多库
  drawMode: 'single' | 'multi'
  // 多库模式下选中的曲库列表（用于抽取）
  selectedPools: string[]
  selectedSong: Song | null
  selectedSongs: Song[]
  activeFilters: Set<Difficulty>
  minLevel: string
  maxLevel: string
  includePlusOnly: boolean
  drawCount: number
  isDrawing: boolean
  drawKey: number
  selectRandomSong: () => void
  drawSongs: (count: number, fromMultiPools?: boolean) => void
  toggleFilter: (difficulty: Difficulty) => void
  setLevelRange: (min: string, max: string) => void
  setIncludePlusOnly: (include: boolean) => void
  resetLevelFilter: () => void
  setDrawCount: (count: number) => void
  setIsDrawing: (isDrawing: boolean) => void
  clearSelectedSongs: () => void
  importSongs: (newSongs: Song[]) => void
  // 多曲库相关方法
  addSongPool: (name: string, songs: Song[]) => string
  removeSongPool: (poolId: string) => void
  setActivePoolId: (poolId: string) => void
  setDrawMode: (mode: 'single' | 'multi') => void
  togglePoolSelection: (poolId: string) => void
  getActiveSongs: () => Song[]
  getFilteredSongs: (activeFilters: Set<Difficulty>, includePlusOnly: boolean, poolSongs?: Song[]) => Song[]
}

const mockSongs: Song[] = [
  
]

export const useSongStore = create<SongStore>((set, get) => ({
  songs: mockSongs,
  songPools: [],
  activePoolId: 'main',
  drawMode: 'single',
  selectedPools: [],
  selectedSong: null,
  selectedSongs: [],
  activeFilters: new Set(['EXPERT', 'MASTER', 'Re:MASTER']),
  minLevel: '1',
  maxLevel: '15',
  includePlusOnly: false,
  drawCount: 1,
  isDrawing: false,
  drawKey: 0,

  // 获取当前激活曲库的歌曲
  getActiveSongs: () => {
    const { songs, songPools, activePoolId } = get()
    if (activePoolId === 'main') {
      // 如果主库为空但有已导入曲库，使用第一个曲库
      if (songs.length === 0 && songPools.length > 0) {
        return songPools[0].songs
      }
      return songs
    }
    const pool = songPools.find(p => p.id === activePoolId)
    return pool?.songs || songs
  },

  // 获取过滤后的歌曲
  getFilteredSongs: (af: Set<Difficulty>, ipOnly: boolean, poolSongs?: Song[]) => {
    const { minLevel, maxLevel } = get()
    const source = poolSongs || get().getActiveSongs()
    const minValue = parseInputValue(minLevel)
    const maxValue = parseInputValue(maxLevel)

    const result: Song[] = []
    for (let i = 0; i < source.length; i++) {
      const song = source[i]
      if (!af.has(song.difficulty)) continue
      const songValue = parseSongLevel(song)
      if (songValue < minValue || songValue > maxValue) continue
      if (ipOnly && !song.isPlus) continue
      result.push(song)
    }
    return result
  },

  selectRandomSong: () => {
    const { activeFilters, includePlusOnly, getFilteredSongs } = get()
    const filteredSongs = getFilteredSongs(activeFilters, includePlusOnly)
    if (filteredSongs.length === 0) return
    const randomIndex = getRandomIndex(filteredSongs.length)
    set({ selectedSong: filteredSongs[randomIndex] })
  },

  drawSongs: (count: number, fromMultiPools?: boolean) => {
    const { activeFilters, includePlusOnly, getFilteredSongs, songPools, drawMode } = get()
    const useMulti = fromMultiPools || (drawMode === 'multi' && count > 1)

    // 多库模式：使用选中的曲库抽取
  if (useMulti) {
    const { selectedPools, songs, songPools } = get()
    const poolsToUse: SongPool[] = []

    // 收集选中的曲库
    for (const poolId of selectedPools) {
      if (poolId === 'main') {
        poolsToUse.push({ id: 'main', name: '主库', songs })
      } else {
        const pool = songPools.find(p => p.id === poolId)
        if (pool) poolsToUse.push(pool)
      }
    }

    if (poolsToUse.length > 0) {
      const result: Song[] = []
      const limitedPools = poolsToUse.slice(0, count)

      for (const pool of limitedPools) {
        const filtered = getFilteredSongs(activeFilters, includePlusOnly, pool.songs)
        if (filtered.length > 0) {
          const randomIndex = getRandomIndex(filtered.length)
          result.push(filtered[randomIndex])
        }
      }

      set({ selectedSongs: result, selectedSong: result.length > 0 ? result[0] : null, drawKey: (get() as SongStore).drawKey + 1 })

      if (typeof window !== 'undefined') {
        broadcastSyncEvent('draw', { songs: result })
      }
      return
    }
  }

    // 单库模式
    const filteredSongs = getFilteredSongs(activeFilters, includePlusOnly)
    if (filteredSongs.length === 0) return

    const result: Song[] = []
    const availableSongs = [...filteredSongs]

    for (let i = 0; i < count && availableSongs.length > 0; i++) {
      const randomIndex = getRandomIndex(availableSongs.length)
      result.push(availableSongs[randomIndex])
      availableSongs.splice(randomIndex, 1)
    }

    set({ selectedSongs: result, selectedSong: result.length > 0 ? result[0] : null, drawKey: (get() as SongStore).drawKey + 1 })

    if (typeof window !== 'undefined') {
      broadcastSyncEvent('draw', { songs: result })
    }
  },

  toggleFilter: (difficulty) => {
    const { activeFilters } = get()
    const newFilters = new Set(activeFilters)
    if (newFilters.has(difficulty)) {
      newFilters.delete(difficulty)
    } else {
      newFilters.add(difficulty)
    }
    set({ activeFilters: newFilters })
  },

  setLevelRange: (min, max) => {
    set({ minLevel: min, maxLevel: max })
  },

  setIncludePlusOnly: (include) => {
    set({ includePlusOnly: include })
  },

  resetLevelFilter: () => {
    set({ minLevel: '1', maxLevel: '15', includePlusOnly: false })
  },

  setDrawCount: (count) => {
    const { selectedPools } = get()
    // 如果已选数量超过新限制，裁剪掉多余的
    if (selectedPools.length > count) {
      set({ drawCount: count, selectedPools: selectedPools.slice(0, count) })
    } else {
      set({ drawCount: count })
    }
  },

  setIsDrawing: (isDrawing) => {
    set({ isDrawing })
  },

  clearSelectedSongs: () => {
    set({ selectedSongs: [], selectedSong: null })
  },

  importSongs: (newSongs: Song[]) => {
    const { songs } = get()
    // 如果主库为空，导入的歌曲直接作为主库
    if (songs.length === 0) {
      set({ songs: newSongs, activePoolId: 'main' })
    } else {
      set({ songs: newSongs })
    }
    if (typeof window !== 'undefined') {
      broadcastSyncEvent('import', { songs: newSongs })
    }
  },

  addSongPool: (name: string, songs: Song[]): string => {
    const { songPools, songs: mainSongs } = get()
    // 如果主库为空，直接作为主库
    if (mainSongs.length === 0) {
      set({ songs, activePoolId: 'main' })
      return 'main'
    }
    const newPool: SongPool = {
      id: `pool-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name,
      songs
    }
    set({ songPools: [...songPools, newPool] })
    return newPool.id
  },

  removeSongPool: (poolId) => {
    const { songPools, activePoolId } = get()
    const newPools = songPools.filter(p => p.id !== poolId)
    // 如果删除的是当前激活的曲库，切换回主库
    if (activePoolId === poolId) {
      set({ songPools: newPools, activePoolId: 'main' })
    } else {
      set({ songPools: newPools })
    }
  },

  setActivePoolId: (poolId) => {
    set({ activePoolId: poolId })
  },

  setDrawMode: (mode) => {
    set({ drawMode: mode })
  },

  togglePoolSelection: (poolId: string) => {
    const { selectedPools, drawCount } = get()
    if (selectedPools.includes(poolId)) {
      set({ selectedPools: selectedPools.filter(id => id !== poolId) })
    } else {
      // 限制最多选择 drawCount 个曲库
      if (selectedPools.length >= drawCount) return
      set({ selectedPools: [...selectedPools, poolId] })
    }
  },
}))
