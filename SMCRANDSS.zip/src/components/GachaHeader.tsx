import { Sparkles, Gift, RotateCcw, Plus, Database } from 'lucide-react'
import { useSongStore } from '@/store/songStore'
import { useState, useEffect, useMemo } from 'react'
import DifficultyFilter from './DifficultyFilter'
import MultiPoolImport from './MultiPoolImport'

const drawCounts = [1, 2, 3]

// 预设难度区间
const presetRanges = [
  { label: '1-7', min: 1, max: 7 },
  { label: '8-11', min: 8, max: 11 },
  { label: '12-13', min: 12, max: 13 },
  { label: '13+', min: 13, max: 15 },
  { label: '14', min: 14, max: 14 },
  { label: '14+', min: 14, max: 15 },
]

/**
 * 解析等级字符串，提取等级数值和是否为+难度
 * 使用 +0.5 的方式表示+难度，便于比较
 */
function parseLevelValue(level: number, isPlus: boolean): number {
  return isPlus ? level + 0.5 : level
}

/**
 * 解析输入值字符串（如 "12+"），返回数值（12.5）
 */
function parseInputValue(val: string): number {
  const hasPlus = val.includes('+')
  const numPart = parseInt(val.replace('+', '')) || 1
  return hasPlus ? numPart + 0.5 : numPart
}

export default function GachaHeader() {
  const { drawCount, setDrawCount, drawSongs, setIsDrawing, minLevel, maxLevel, setLevelRange, includePlusOnly, setIncludePlusOnly, resetLevelFilter, songPools, drawMode, setDrawMode, selectedPools } = useSongStore()
  const [shaking, setShaking] = useState(false)
  const [showLevelSelector, setShowLevelSelector] = useState(false)
  const [tempMin, setTempMin] = useState(minLevel)
  const [tempMax, setTempMax] = useState(maxLevel)
  const [showPoolManager, setShowPoolManager] = useState(false)

  // 当外部状态变化时同步临时状态
  useEffect(() => {
    setTempMin(minLevel)
    setTempMax(maxLevel)
  }, [minLevel, maxLevel])

  // 订阅所有影响筛选的状态（使用 selector 避免不必要的重渲染）
  const songs = useSongStore((state) => state.songs)
  const activeFilters = useSongStore((state) => state.activeFilters)

  // 使用 useMemo 缓存过滤结果，仅在依赖变化时重新计算
  const filteredCount = useMemo(() => {
    const minValue = parseInputValue(tempMin)
    const maxValue = parseInputValue(tempMax)

    let count = 0
    for (let i = 0; i < songs.length; i++) {
      const song = songs[i]
      if (!activeFilters.has(song.difficulty)) continue
      const songValue = parseLevelValue(song.level, song.isPlus)
      if (songValue < minValue || songValue > maxValue) continue
      if (includePlusOnly && !song.isPlus) continue
      count++
    }
    return count
  }, [songs, activeFilters, tempMin, tempMax, includePlusOnly])

  const handleDraw = () => {
    if (filteredCount === 0) return

    setShaking(true)
    setIsDrawing(true)

    setTimeout(() => {
      drawSongs(drawCount)
      setShaking(false)
      setIsDrawing(false)
    }, 2000)
  }

  const handleApplyLevelRange = () => {
    // 确保值有效
    const minLvl = parseInt(tempMin.replace('+', '')) || 1
    const maxLvl = parseInt(tempMax.replace('+', '')) || 15
    const minHasPlus = tempMin.includes('+')
    const maxHasPlus = tempMax.includes('+')
    setLevelRange(
      minLvl + (minHasPlus ? '+' : ''),
      maxLvl + (maxHasPlus ? '+' : '')
    )
  }

  const handleResetLevelFilter = () => {
    setTempMin('1')
    setTempMax('15')
    setIncludePlusOnly(false)
    resetLevelFilter()
  }

  const handlePresetRange = (min: number, max: number) => {
    setTempMin(min.toString())
    setTempMax(max.toString())
    setLevelRange(min.toString(), max.toString())
  }

  return (
    <header className="relative py-6 px-4 bg-gradient-to-b from-blue-700 to-dark-bg border-b-4 border-blue-500">
      {/* Decorative top bar */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-red-500 via-yellow-500 to-pink-500" />

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Title Section */}
        <div className="text-center mb-6">
          <div className="inline-block bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-2 rounded-xl border-3 border-blue-400 mb-3 shadow-lg">
            <p className="text-white font-rajdhani font-bold text-lg">
              请选择要抽取的曲目数量
            </p>
          </div>
          <h1 className="font-orbitron font-black text-3xl md:text-4xl text-white drop-shadow-lg mb-1">
            抽卡选曲
          </h1>
          {filteredCount > 0 && (
            <p className="font-rajdhani text-blue-200 text-sm">
              共有 {filteredCount} 张可抽选的谱面
            </p>
          )}
        </div>

        {/* Count Selector */}
        <div className="flex justify-center gap-3 mb-6">
          {drawCounts.map((count) => (
            <button
              key={count}
              onClick={() => setDrawCount(count)}
              disabled={shaking}
              className={`
                relative px-6 py-3 rounded-xl font-orbitron font-black text-base
                transition-all duration-200 border-4 shadow-lg
                ${shaking ? 'opacity-50 cursor-not-allowed' : ''}
                ${drawCount === count
                  ? 'text-white bg-gradient-to-b from-yellow-500 to-orange-600 border-yellow-300 scale-110 shadow-yellow-500/50'
                  : 'text-white bg-gradient-to-b from-blue-600 to-blue-700 border-blue-400 hover:from-blue-500 hover:to-blue-600'
                }
              `}
            >
              {count} 张谱面
            </button>
          ))}
        </div>

        {/* Multi-pool Management Button */}
        {(drawCount === 2 || drawCount === 3) && (
          <div className="flex flex-col items-center gap-3 mb-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowPoolManager(!showPoolManager)}
                className="relative px-6 py-2 rounded-xl font-rajdhani font-bold text-white text-sm
                  bg-gradient-to-b from-green-600 to-green-700 border-4 border-green-400 shadow-lg
                  hover:from-green-500 hover:to-green-600 transition-all duration-200 flex items-center gap-2"
              >
                <Database size={16} />
                曲库管理 {showPoolManager ? '▲' : '▼'}
              </button>
              {songPools.length > 0 && (
                <button
                  onClick={() => setDrawMode(drawMode === 'multi' ? 'single' : 'multi')}
                  className={`
                    relative px-6 py-2 rounded-xl font-rajdhani font-bold text-white text-sm
                    border-4 shadow-lg transition-all duration-200
                    ${drawMode === 'multi'
                      ? 'bg-gradient-to-b from-yellow-500 to-orange-600 border-yellow-300'
                      : 'bg-gradient-to-b from-slate-600 to-slate-700 border-slate-400'
                    }
                  `}
                >
                  {drawMode === 'multi' ? '多库抽取 ✓' : '单库抽取'}
                </button>
              )}
            </div>

            {/* Pool manager panel */}
            {showPoolManager && (
              <MultiPoolImport />
            )}

            {/* Pool info when in multi mode */}
            {drawMode === 'multi' && (
              <div className="text-center">
                <p className="text-green-200 text-sm font-rajdhani">
                  多库模式: 将从选中的 {selectedPools.length} 个曲库中各抽取 1 张
                </p>
              </div>
            )}
          </div>
        )}

        {/* Level Range Selector */}
        <div className="flex flex-col items-center gap-3 mb-6">
          <button
            onClick={() => setShowLevelSelector(!showLevelSelector)}
            className="relative px-6 py-2 rounded-xl font-rajdhani font-bold text-white text-sm
              bg-gradient-to-b from-purple-600 to-purple-700 border-4 border-purple-400 shadow-lg
              hover:from-purple-500 hover:to-purple-600 transition-all duration-200"
          >
            难度区间选择 {showLevelSelector ? '▲' : '▼'}
          </button>

          {showLevelSelector && (
            <div className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-xl border-2 border-blue-400 p-4 shadow-xl w-full max-w-md">
              {/* 预设区间 */}
              <div className="mb-4">
                <p className="text-blue-200 text-sm font-rajdhani font-semibold mb-2">快速选择</p>
                <div className="flex flex-wrap gap-2">
                  {presetRanges.map((range) => {
                    const isActive = minLevel === range.min.toString() && maxLevel === range.max.toString()
                    return (
                      <button
                        key={range.label}
                        onClick={() => handlePresetRange(range.min, range.max)}
                        className={`
                          px-3 py-1 rounded-lg text-sm font-bold transition-all duration-200 border-2
                          ${isActive
                            ? 'bg-gradient-to-b from-yellow-500 to-orange-600 border-yellow-300 text-white'
                            : 'bg-gradient-to-b from-blue-600 to-blue-700 border-blue-400 text-white hover:from-blue-500 hover:to-blue-600'
                          }
                        `}
                      >
                        {range.label}
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* 自定义区间 */}
              <div className="mb-4">
                <p className="text-blue-200 text-sm font-rajdhani font-semibold mb-2">自定义范围</p>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={tempMin}
                      onChange={(e) => {
                        const val = e.target.value.replace(/[^0-9+]/g, '')
                        const numPart = val.replace('+', '')
                        if (!numPart) {
                          setTempMin('')
                        } else if (parseInt(numPart) >= 1 && parseInt(numPart) <= 15) {
                          // 只允许末尾有一个+
                          const hasPlus = val.includes('+')
                          setTempMin(numPart + (hasPlus ? '+' : ''))
                        }
                      }}
                      className="w-16 px-2 py-1 rounded-lg bg-slate-700 text-white border border-blue-400 font-bold text-center"
                      placeholder="1"
                    />
                  </div>
                  <span className="text-blue-200 font-bold">-</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={tempMax}
                      onChange={(e) => {
                        const val = e.target.value.replace(/[^0-9+]/g, '')
                        const numPart = val.replace('+', '')
                        if (!numPart) {
                          setTempMax('')
                        } else if (parseInt(numPart) >= 1 && parseInt(numPart) <= 15) {
                          // 只允许末尾有一个+
                          const hasPlus = val.includes('+')
                          setTempMax(numPart + (hasPlus ? '+' : ''))
                        }
                      }}
                      className="w-16 px-2 py-1 rounded-lg bg-slate-700 text-white border border-blue-400 font-bold text-center"
                      placeholder="15"
                    />
                  </div>
                  <button
                    onClick={handleApplyLevelRange}
                    className="px-4 py-1 rounded-lg bg-gradient-to-b from-green-500 to-green-600 text-white font-bold border border-green-400 hover:from-green-400 hover:to-green-500 transition-all duration-200"
                  >
                    应用
                  </button>
                </div>
              </div>

              {/* 只选+难度 */}
              <div className="mb-4">
                <button
                  onClick={() => setIncludePlusOnly(!includePlusOnly)}
                  className={`
                    w-full px-4 py-2 rounded-lg text-sm font-bold transition-all duration-200 border-2 flex items-center justify-center gap-2
                    ${includePlusOnly
                      ? 'bg-gradient-to-b from-yellow-500 to-orange-600 border-yellow-300 text-white'
                      : 'bg-gradient-to-b from-slate-600 to-slate-700 border-slate-400 text-white hover:from-slate-500 hover:to-slate-600'
                    }
                  `}
                >
                  <Plus size={16} />
                  只选择 + 难度
                </button>
              </div>

              {/* 重置按钮 */}
              <button
                onClick={handleResetLevelFilter}
                className="w-full px-4 py-2 rounded-lg bg-gradient-to-b from-red-500 to-red-600 text-white font-bold border border-red-400 hover:from-red-400 hover:to-red-500 transition-all duration-200 flex items-center justify-center gap-2"
              >
                <RotateCcw size={16} />
                重置筛选
              </button>

              {/* 当前筛选状态 */}
              <div className="mt-3 text-center">
                <p className="text-blue-200 text-xs">
                  当前筛选: 等级 {minLevel}-{maxLevel}
                  {includePlusOnly && '（仅+难度）'}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Draw Button */}
        <div className="flex flex-col items-center gap-4 mb-6">
          <button
            onClick={handleDraw}
            disabled={filteredCount === 0 || shaking}
            className={`
              group relative px-16 py-6 rounded-2xl font-orbitron font-black text-white text-2xl
              shadow-xl transition-all duration-300 border-4 overflow-hidden
              ${filteredCount === 0 || shaking
                ? 'bg-gray-500 border-gray-400 cursor-not-allowed opacity-50'
                : 'bg-gradient-to-b from-red-500 to-red-700 border-red-300 hover:from-red-400 hover:to-red-600 hover:shadow-red-500/50'
              }
              ${shaking ? 'animate-gachaShake' : 'hover:scale-105'}
            `}
          >
            {/* Animated shimmer background */}
            {!shaking && filteredCount > 0 && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-shimmer" />
            )}
            <span className="relative z-10 flex items-center gap-4">
              <Gift size={36} className={shaking ? 'animate-gachaBounce' : 'group-hover:rotate-12 transition-transform duration-300'} />
              {shaking ? '抽卡中...' : '开始抽卡'}
              <Sparkles size={32} className={shaking ? 'animate-gachaSparkle' : 'opacity-80'} />
            </span>
          </button>
        </div>

        {/* Difficulty Filter */}
        <div className="flex flex-col items-center gap-3">
          <span className="font-rajdhani text-blue-200 text-sm uppercase tracking-wider font-semibold">难度筛选</span>
          <DifficultyFilter />
        </div>
      </div>
    </header>
  )
}