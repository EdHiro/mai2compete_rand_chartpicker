import { useMemo, useState, useEffect, useRef, useCallback } from 'react'
import SongCard from './SongCard'
import { useSongStore } from '@/store/songStore'
import { Disc3, Library } from 'lucide-react'

const CARD_WIDTH = 300
const CARD_HEIGHT = 520
const CARD_GAP = 32 // 8 gap * 4 (tailwind gap-8 = 2rem = 32px)
const CONTAINER_PADDING_X = 32 // px-4 = 1rem = 16px * 2

export default function SongList() {
  const songs = useSongStore((state) => state.songs)
  const songPools = useSongStore((state) => state.songPools)
  const activePoolId = useSongStore((state) => state.activePoolId)
  const setActivePoolId = useSongStore((state) => state.setActivePoolId)
  const activeFilters = useSongStore((state) => state.activeFilters)
  const mainSongCount = useSongStore((state) => state.songs.length)

  // 根据 activePoolId 获取当前激活曲库的歌曲
  const activeSongs = useMemo(() => {
    if (activePoolId === 'main') return songs
    const pool = songPools.find(p => p.id === activePoolId)
    return pool?.songs || songs
  }, [songs, songPools, activePoolId])

  // 根据难度过滤
  const filteredSongs = useMemo(
    () => activeSongs.filter(song => activeFilters.has(song.difficulty)),
    [activeSongs, activeFilters]
  )

  // 虚拟滚动相关状态
  const containerRef = useRef<HTMLDivElement>(null)
  const [scrollTop, setScrollTop] = useState(0)
  const [containerWidth, setContainerWidth] = useState(0)
  const [containerHeight, setContainerHeight] = useState(0)

  // 计算每行卡片数量
  const cardsPerRow = useMemo(() => {
    if (containerWidth <= 0) return 1
    const availableWidth = containerWidth - CONTAINER_PADDING_X
    return Math.max(1, Math.floor((availableWidth + CARD_GAP) / (CARD_WIDTH + CARD_GAP)))
  }, [containerWidth])

  // 计算总行数
  const totalRows = useMemo(() => {
    if (filteredSongs.length === 0) return 0
    return Math.ceil(filteredSongs.length / cardsPerRow)
  }, [filteredSongs.length, cardsPerRow])

  // 虚拟滚动：计算可见的行范围
  const BUFFER_ROWS = 2 // 上下各多渲染 2 行作为缓冲
  const { startRow, endRow } = useMemo(() => {
    if (containerHeight <= 0) return { startRow: 0, endRow: 0 }
    const firstVisibleRow = Math.max(0, Math.floor(scrollTop / (CARD_HEIGHT + CARD_GAP)) - BUFFER_ROWS)
    const visibleRowCount = Math.ceil(containerHeight / (CARD_HEIGHT + CARD_GAP))
    const lastVisibleRow = Math.min(totalRows - 1, firstVisibleRow + visibleRowCount + BUFFER_ROWS * 2)
    return { startRow: firstVisibleRow, endRow: lastVisibleRow }
  }, [scrollTop, containerHeight, totalRows])

  // 计算可见范围内的卡片
  const visibleCards = useMemo(() => {
    const startIndex = startRow * cardsPerRow
    const endIndex = Math.min((endRow + 1) * cardsPerRow, filteredSongs.length)
    const cards: { song: typeof filteredSongs[0]; rowIndex: number; colIndex: number }[] = []
    
    for (let i = startIndex; i < endIndex; i++) {
      const song = filteredSongs[i]
      if (!song) continue
      const rowIndex = Math.floor(i / cardsPerRow)
      const colIndex = i % cardsPerRow
      cards.push({ song, rowIndex, colIndex })
    }
    return cards
  }, [startRow, endRow, cardsPerRow, filteredSongs])

  // 获取容器尺寸
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const updateSize = () => {
      const rect = container.getBoundingClientRect()
      setContainerWidth(rect.width)
      setContainerHeight(rect.height)
    }

    updateSize()
    
    const resizeObserver = new ResizeObserver(updateSize)
    resizeObserver.observe(container)
    
    return () => resizeObserver.disconnect()
  }, [])

  // 滚动事件处理（使用 requestAnimationFrame 节流）
  const rafRef = useRef<number | null>(null)
  const handleScroll = useCallback(() => {
    if (rafRef.current !== null) return
    rafRef.current = requestAnimationFrame(() => {
      if (containerRef.current) {
        setScrollTop(containerRef.current.scrollTop)
      }
      rafRef.current = null
    })
  }, [])

  if (filteredSongs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-white/70">
        <Disc3 size={64} className="mb-4 opacity-50" />
        <p className="font-rajdhani text-lg">没有符合条件的歌曲</p>
      </div>
    )
  }

  return (
    <div className="relative">
      {/* 曲库切换器 */}
      {songPools.length > 0 && (
        <div className="max-w-6xl mx-auto mb-6">
          <div className="flex items-center gap-3 mb-3">
            <Library size={18} className="text-blue-400" />
            <span className="text-white font-rajdhani font-bold text-sm">切换曲库</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActivePoolId('main')}
              className={`px-4 py-2 rounded-lg font-rajdhani font-bold text-sm transition-all duration-200 ${
                activePoolId === 'main'
                  ? 'bg-gradient-to-b from-blue-600 to-blue-700 text-white border-2 border-blue-400 shadow-lg'
                  : 'bg-slate-700/50 text-slate-300 border-2 border-slate-600 hover:bg-slate-600'
              }`}
            >
              主库 ({mainSongCount})
            </button>
            {songPools.map((pool) => (
              <button
                key={pool.id}
                onClick={() => setActivePoolId(pool.id)}
                className={`px-4 py-2 rounded-lg font-rajdhani font-bold text-sm transition-all duration-200 ${
                  activePoolId === pool.id
                    ? 'bg-gradient-to-b from-purple-600 to-purple-700 text-white border-2 border-purple-400 shadow-lg'
                    : 'bg-slate-700/50 text-slate-300 border-2 border-slate-600 hover:bg-slate-600'
                }`}
              >
                {pool.name} ({pool.songs.length})
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 显示当前曲目数量 */}
      <div className="max-w-6xl mx-auto mb-4 text-center">
        <span className="text-slate-400 text-sm font-rajdhani">
          共 {filteredSongs.length} 首曲目
        </span>
      </div>

      {/* 虚拟滚动容器 */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="relative overflow-y-auto overflow-x-hidden"
        style={{ maxHeight: 'calc(100vh - 280px)' }}
      >
        {/* 占位元素，设置总高度 */}
        <div
          style={{
            height: totalRows * (CARD_HEIGHT + CARD_GAP) - CARD_GAP,
            position: 'relative',
          }}
        >
          {/* 可见范围内的卡片 */}
          {visibleCards.map(({ song, rowIndex, colIndex }) => (
            <div
              key={song.id}
              className="absolute"
              style={{
                top: rowIndex * (CARD_HEIGHT + CARD_GAP),
                left: `calc(${CONTAINER_PADDING_X / 2}px + ${colIndex * (CARD_WIDTH + CARD_GAP)}px + (100% - ${CONTAINER_PADDING_X}px - ${cardsPerRow * (CARD_WIDTH + CARD_GAP) - CARD_GAP}px) / 2)`,
              }}
            >
              <SongCard song={song} />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
