import { useEffect, useState } from "react";
import Home from "@/pages/Home";
import OBSDisplay from "@/pages/OBSDisplay";

export default function App() {
  const [isOBS, setIsOBS] = useState(false);

  useEffect(() => {
    setIsOBS(window.location.pathname === "/obs" || window.location.search.includes("obs=1"));
  }, []);

  if (isOBS) {
    return <OBSDisplay />;
  }

  return <Home />;
}
